"use server";

import { prisma } from "@/lib/prisma";
import { revalidatePath } from "next/cache";
import type { PaymentMethod } from "@prisma/client";

// TODO(auth): replace with the real authenticated cashier id from the session.
async function resolveCashierId(): Promise<string> {
  const kasir = await prisma.user.findFirst({
    where: { role: "KASIR", isActive: true },
    select: { id: true },
  });
  if (kasir) return kasir.id;
  const any = await prisma.user.findFirst({
    where: { isActive: true },
    select: { id: true },
  });
  if (!any) throw new Error("Tidak ada user untuk dijadikan kasir.");
  return any.id;
}

const PAY_MAP: Record<string, PaymentMethod> = {
  cash: "CASH",
  qris: "QRIS",
  card: "CARD",
};

export type CheckoutLine = {
  productId: string; // real DB product id (POS catalog uses it as the key)
  qty: number;       // in kg (may be fractional)
  sellPrice: number; // unit sell price shown at checkout
};

export type CheckoutInput = {
  lines: CheckoutLine[];
  payMethod: "cash" | "qris" | "card";
  // The exact total the customer paid (subtotal − discount + tax + grind fees),
  // persisted as totalAmount so the record matches the receipt.
  total: number;
};

export type CheckoutResult = {
  ok: boolean;
  trxNumber?: string;
  error?: string;
};

export async function checkoutAction(input: CheckoutInput): Promise<CheckoutResult> {
  if (!input.lines || input.lines.length === 0) {
    return { ok: false, error: "Keranjang kosong." };
  }

  const cashierId = await resolveCashierId();
  const paymentMethod = PAY_MAP[input.payMethod];
  if (!paymentMethod) return { ok: false, error: "Metode pembayaran tidak valid." };

  try {
    const trxNumber = await prisma.$transaction(async (tx) => {
      // Generate next TRX number: TRX-#### based on current max.
      const last = await tx.transaction.findFirst({
        orderBy: { trxNumber: "desc" },
        select: { trxNumber: true },
      });
      const lastNum = last ? parseInt(last.trxNumber.replace(/\D/g, ""), 10) || 0 : 0;
      const trxNumber = `TRX-${String(lastNum + 1).padStart(4, "0")}`;

      let totalCogs = 0;
      let grossProfit = 0;
      const itemsData = [];

      for (const line of input.lines) {
        const product = await tx.product.findUnique({
          where: { id: line.productId },
          select: {
            id: true,
            stockKg: true,
            sellPrice: true,
            supplierProducts: {
              where: { isActive: true },
              orderBy: { createdAt: "asc" },
              take: 1,
              select: { buyPricePerKg: true },
            },
          },
        });
        if (!product) throw new Error("Produk dalam keranjang tidak ditemukan.");

        // Guard against overselling.
        if (product.stockKg < line.qty) {
          throw new Error(`Stok tidak cukup untuk salah satu produk (tersisa ${product.stockKg} kg).`);
        }

        const buyPrice = product.supplierProducts[0]?.buyPricePerKg ?? 0;
        const sellPrice = line.sellPrice;
        const subtotal = sellPrice * line.qty;
        const profit = (sellPrice - buyPrice) * line.qty;

        totalCogs += buyPrice * line.qty;
        grossProfit += profit;

        itemsData.push({
          productId: product.id,
          qtyKg: line.qty,
          sellPricePerKg: sellPrice,
          buyPricePerKg: buyPrice,
          subtotal,
          profit,
        });

        // Decrement stock + write stock log.
        const before = product.stockKg;
        const after = before - line.qty;
        await tx.product.update({
          where: { id: product.id },
          data: { stockKg: after },
        });
        await tx.stockLog.create({
          data: {
            productId: product.id,
            type: "SALE",
            qtyChange: -line.qty,
            qtyBefore: before,
            qtyAfter: after,
            referenceType: "Transaction",
            note: `Penjualan ${trxNumber}`,
            createdById: cashierId,
          },
        });
      }

      const created = await tx.transaction.create({
        data: {
          trxNumber,
          paymentMethod,
          status: "PAID",
          totalAmount: input.total,
          totalCogs,
          grossProfit,
          cashierId,
          paidAt: new Date(),
          items: { create: itemsData },
        },
        select: { trxNumber: true },
      });

      return created.trxNumber;
    });

    revalidatePath("/pos");
    revalidatePath("/transactions");
    revalidatePath("/reports");
    return { ok: true, trxNumber };
  } catch (err) {
    const message = err instanceof Error ? err.message : "Gagal memproses transaksi.";
    return { ok: false, error: message };
  }
}
